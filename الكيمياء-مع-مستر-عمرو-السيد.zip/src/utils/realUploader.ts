/**
 * Real Multi-Gigabyte File & 4K Video Uploader with Live Progress Tracking
 * Reports real-time uploaded bytes, total bytes, speed (MB/s), duration (min:sec), and estimated remaining time.
 */

export interface ProgressPayload {
  percent: number;
  loadedFormatted: string;
  totalFormatted: string;
  speed: string;
  remaining: string;
  rawLoaded: number;
  rawTotal: number;
}

export function formatBytes(bytes: number): string {
  if (isNaN(bytes) || bytes <= 0) return '0 B';
  if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
  if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  return (bytes / 1024).toFixed(0) + ' KB';
}

export function formatSecondsToTime(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds <= 0) return '00:00';
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = Math.floor(totalSeconds % 60);
  const pad = (n: number) => (n < 10 ? `0${n}` : `${n}`);

  if (hrs > 0) {
    return `${hrs}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

export function formatDurationArabic(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds <= 0) return 'دقيقة واحدة';
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = Math.floor(totalSeconds % 60);

  const parts: string[] = [];
  if (hrs > 0) parts.push(`${hrs} ساعة`);
  if (mins > 0) parts.push(`${mins} دقيقة`);
  if (secs > 0 || parts.length === 0) parts.push(`${secs} ثانية`);
  return parts.join(' و ');
}

/**
 * Probes the exact duration of a local video file in seconds using HTML5 video metadata
 */
export function probeVideoDuration(file: File): Promise<{ durationSeconds: number; formatted: string }> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    const blobUrl = URL.createObjectURL(file);

    video.onloadedmetadata = () => {
      URL.revokeObjectURL(blobUrl);
      const secs = Math.round(video.duration);
      resolve({
        durationSeconds: secs,
        formatted: formatDurationArabic(secs),
      });
    };

    video.onerror = () => {
      URL.revokeObjectURL(blobUrl);
      resolve({
        durationSeconds: 3600,
        formatted: '60 دقيقة',
      });
    };

    video.src = blobUrl;
  });
}

/**
 * Uploads any file directly to /api/upload-file via XMLHttpRequest with streaming and live progress
 */
export function uploadFileWithRealProgress(
  file: File,
  onProgress: (p: ProgressPayload) => void,
  onSuccess: (data: { url: string; fileName: string; fileSize: string; sizeBytes: number }) => void,
  onError: (errMsg: string) => void
): XMLHttpRequest {
  const xhr = new XMLHttpRequest();
  const startTime = Date.now();
  let lastLoaded = 0;
  let lastTime = startTime;

  xhr.open('POST', '/api/upload-file', true);
  xhr.setRequestHeader('x-file-name', encodeURIComponent(file.name));
  xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');

  const formatRemaining = (seconds: number) => {
    if (!isFinite(seconds) || seconds <= 0) return 'لحظات...';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    if (m > 0) return `${m} دقيقة و ${s} ثانية`;
    return `${s} ثانية`;
  };

  xhr.upload.onprogress = (e) => {
    if (e.lengthComputable && e.total > 0) {
      const now = Date.now();
      const elapsedSec = (now - startTime) / 1000;
      const percent = Math.min(99, Math.round((e.loaded / e.total) * 100));

      const timeDelta = (now - lastTime) / 1000;
      let speedBps = 0;
      if (timeDelta > 0.4) {
        speedBps = (e.loaded - lastLoaded) / timeDelta;
        lastLoaded = e.loaded;
        lastTime = now;
      } else if (elapsedSec > 0) {
        speedBps = e.loaded / elapsedSec;
      }

      const remainingBytes = e.total - e.loaded;
      const remainingSec = speedBps > 0 ? remainingBytes / speedBps : 0;

      onProgress({
        percent,
        loadedFormatted: formatBytes(e.loaded),
        totalFormatted: formatBytes(e.total),
        speed: speedBps > 0 ? `${formatBytes(speedBps)}/ثانية` : 'جارِ الحساب...',
        remaining: formatRemaining(remainingSec),
        rawLoaded: e.loaded,
        rawTotal: e.total,
      });
    }
  };

  xhr.onload = () => {
    if (xhr.status >= 200 && xhr.status < 300) {
      try {
        const res = JSON.parse(xhr.responseText);
        if (res.success && res.url) {
          onProgress({
            percent: 100,
            loadedFormatted: formatBytes(file.size),
            totalFormatted: formatBytes(file.size),
            speed: 'مكتمل',
            remaining: '0 ثانية',
            rawLoaded: file.size,
            rawTotal: file.size,
          });
          onSuccess(res);
        } else {
          onError(res.error || 'تعذر استكمال رفع الملف على الخادم.');
        }
      } catch {
        onError('حدث خطأ في معالجة استجابة الخادم.');
      }
    } else {
      onError(`فشل الرفع عبر الخادم (كود: ${xhr.status})`);
    }
  };

  xhr.onerror = () => {
    onError('انقطع الاتصال أثناء رفع الملف، يرجى المحاولة مرة أخرى.');
  };

  xhr.send(file);
  return xhr;
}
