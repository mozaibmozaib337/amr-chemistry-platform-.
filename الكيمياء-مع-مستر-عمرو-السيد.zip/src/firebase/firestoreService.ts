import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  limit,
} from 'firebase/firestore';
import { db } from './config';

/**
 * Real-time listener for a Firestore collection.
 * Calls `onUpdate` whenever changes occur anywhere on any client or device.
 */
export function subscribeToCollection<T>(
  collectionName: string,
  onUpdate: (items: T[]) => void,
  initialSeed?: T[]
): () => void {
  const colRef = collection(db, collectionName);

  const unsubscribe = onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty && initialSeed && initialSeed.length > 0) {
        // First-time automatic seed to populate existing curriculum for all students
        try {
          const promises = initialSeed.map((item: any) => {
            const docId = item.id || item.code;
            if (!docId) return Promise.resolve();
            const cleanItem = sanitizeData(item);
            return setDoc(doc(db, collectionName, String(docId)), cleanItem, { merge: true });
          });
          await Promise.all(promises);
        } catch (err) {
          console.warn(`[Firestore] Initial seed error for ${collectionName}:`, err);
        }
        onUpdate(initialSeed);
        return;
      }

      const items: T[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({ id: docSnap.id, ...data } as unknown as T);
      });
      onUpdate(items);
    },
    (error) => {
      console.warn(`[Firestore] Snapshot error on ${collectionName}:`, error);
    }
  );

  return unsubscribe;
}

/**
 * Remove undefined values as Firestore throws error on undefined
 */
function sanitizeData(obj: any): any {
  if (obj === undefined) return null;
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    return obj.map(sanitizeData);
  }
  const clean: Record<string, any> = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== undefined) {
      clean[key] = sanitizeData(val);
    }
  }
  return clean;
}

/**
 * Save or overwrite a document by ID in Firestore
 */
export async function saveDocument(collectionName: string, id: string, data: any): Promise<void> {
  try {
    const clean = sanitizeData(data);
    await setDoc(doc(db, collectionName, id), clean, { merge: true });
  } catch (err) {
    console.warn(`[Firestore] Error saving to ${collectionName}/${id}:`, err);
  }
}

/**
 * Update partial fields of a document in Firestore
 */
export async function updateDocument(collectionName: string, id: string, partial: any): Promise<void> {
  try {
    const clean = sanitizeData(partial);
    await updateDoc(doc(db, collectionName, id), clean);
  } catch (err) {
    // If doc didn't exist yet, fallback to setDoc
    try {
      const clean = sanitizeData(partial);
      await setDoc(doc(db, collectionName, id), clean, { merge: true });
    } catch (e) {
      console.warn(`[Firestore] Error updating ${collectionName}/${id}:`, e);
    }
  }
}

/**
 * Delete a document from Firestore
 */
export async function deleteDocument(collectionName: string, id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, collectionName, id));
  } catch (err) {
    console.warn(`[Firestore] Error deleting from ${collectionName}/${id}:`, err);
  }
}

/**
 * Bulk save items into Firestore
 */
export async function bulkSaveDocuments<T extends { id: string }>(
  collectionName: string,
  items: T[]
): Promise<void> {
  try {
    const promises = items.map((item) => {
      const clean = sanitizeData(item);
      return setDoc(doc(db, collectionName, item.id), clean, { merge: true });
    });
    await Promise.all(promises);
  } catch (err) {
    console.warn(`[Firestore] Error bulk saving to ${collectionName}:`, err);
  }
}
