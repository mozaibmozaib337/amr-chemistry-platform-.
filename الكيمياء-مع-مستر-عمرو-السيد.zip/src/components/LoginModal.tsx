import React, { useState } from 'react';
import { usePlatform, ADMIN_EMAIL } from '../context/PlatformContext';
import {
  X,
  Mail,
  User,
  Lock,
  UserPlus,
  AlertCircle,
  KeyRound,
  GraduationCap,
  MapPin,
  Phone,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { GradeLevel, SubscriptionType } from '../types';

export const LoginModal: React.FC = () => {
  const { isLoginModalOpen, setIsLoginModalOpen, loginStrict, registerStrict, login } = usePlatform();
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginCode, setLoginCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Register form state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regParentPhone, setRegParentPhone] = useState('');
  const [regGrade, setRegGrade] = useState<GradeLevel>('sec3');
  const [regGov, setRegGov] = useState('القاهرة');

  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);

  if (!isLoginModalOpen) return null;

  const [quickGmail, setQuickGmail] = useState('');
  const [quickName, setQuickName] = useState('');
  const [loginMethod, setLoginMethod] = useState<'quick_gmail' | 'password'>('quick_gmail');

  const handleQuickGmailLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setStatusMessage(null);
    const email = (quickGmail || loginIdentifier).trim();

    if (!email) {
      setStatusMessage({ text: 'يرجى كتابة عنوان البريد الإلكتروني (Gmail).', isError: true });
      return;
    }

    setIsLoading(true);

    // Direct Master Admin bypass
    if (
      email.toLowerCase() === 'amr12345@gmail.com' ||
      email.toLowerCase() === ADMIN_EMAIL.toLowerCase() ||
      email === '01069780486' ||
      email === '+20 10 69780486'
    ) {
      const res = loginStrict(email, '', '');
      if (res.success) {
        setIsLoginModalOpen(false);
        resetFields();
      }
      setIsLoading(false);
      return;
    }

    // Auto extract student name from Gmail if not provided
    const defaultName = quickName.trim() || email.split('@')[0].replace(/[._-]/g, ' ') || 'طالب كيمياء معتمد';
    const generatedCode = `AMR-${Math.floor(10000 + Math.random() * 90000)}`;

    try {
      // Direct sync with Supabase for permanent 300,000+ student storage
      const { saveStudentToSupabase } = await import('../utils/supabaseStorage');
      await saveStudentToSupabase({
        full_name: defaultName,
        email: email,
        phone: '010' + Math.floor(10000000 + Math.random() * 90000000),
        student_code: generatedCode,
        grade: '3 ثانوي',
      });
    } catch (e) {
      console.warn('Supabase auto-sync note:', e);
    }

    // Immediate session activation (zero password required!)
    login(email, defaultName, '', 'sec3', generatedCode);
    setIsLoading(false);
    setIsLoginModalOpen(false);
    resetFields();
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (loginMethod === 'quick_gmail') {
      return handleQuickGmailLogin(e);
    }

    const trimmedId = loginIdentifier.trim();
    if (!trimmedId) {
      setStatusMessage({ text: 'يرجى إدخال البريد الإلكتروني أو رقم الهاتف أو كود الطالب.', isError: true });
      return;
    }

    // Direct Master Admin bypass for Mr. Amr El-Sayed (amr12345@gmail.com / 01069780486)
    if (
      trimmedId.toLowerCase() === 'amr12345@gmail.com' ||
      trimmedId.toLowerCase() === ADMIN_EMAIL.toLowerCase() ||
      trimmedId === '01069780486' ||
      trimmedId === '+20 10 69780486'
    ) {
      const res = loginStrict(trimmedId, '', loginCode);
      if (res.success) {
        setIsLoginModalOpen(false);
        resetFields();
      }
      return;
    }

    if (!loginPassword.trim()) {
      setStatusMessage({ text: 'يرجى كتابة كلمة المرور الخاصة بحسابك أو استخدام الدخول السريع بالجيميل.', isError: true });
      return;
    }

    setIsLoading(true);

    // 1. First attempt strict local matching
    const localRes = loginStrict(trimmedId, loginPassword.trim(), loginCode.trim());
    if (localRes.success) {
      setIsLoading(false);
      setIsLoginModalOpen(false);
      resetFields();
      return;
    }

    // 2. If not matched locally (e.g. registered in another browser), attempt direct server-authoritative login
    try {
      const srvRes = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: trimmedId,
          password: loginPassword.trim(),
          code: loginCode.trim(),
        }),
      });

      const data = await srvRes.json();
      if (data.success && data.account) {
        const acc = data.account;
        login(
          acc.email || `${acc.phone}@amr-chem.com`,
          acc.name,
          acc.phone,
          acc.grade,
          acc.studentCode
        );
        setIsLoading(false);
        setIsLoginModalOpen(false);
        resetFields();
        return;
      } else {
        setStatusMessage({
          text: data.error || localRes.error || 'فشل تسجيل الدخول. يرجى التأكد من صحة البريد أو الهاتف أو استخدام الدخول السريع بالجيميل.',
          isError: true,
        });
      }
    } catch {
      setStatusMessage({
        text: localRes.error || 'تعذر تسجيل الدخول. يمكنك استخدام الدخول السريع بالجيميل بدون كلمة سر.',
        isError: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    if (!regName.trim() || !regPhone.trim() || !regPassword.trim()) {
      setStatusMessage({ text: 'يرجى كتابة اسم الطالب، ورقم الهاتف، وكلمة المرور.', isError: true });
      return;
    }

    if (!regParentPhone.trim()) {
      setStatusMessage({ text: 'يرجى إدخال رقم هاتف ولي الأمر (إلزامي لمتابعة الطالب وإرسال التقارير).', isError: true });
      return;
    }

    setIsLoading(true);
    const finalCode = `AMR-${Math.floor(1000 + Math.random() * 9000)}`;
    const finalEmail = regEmail.trim() || `${regPhone.trim()}@student.amr-chem.com`;

    try {
      // 1. Direct Server Persistence
      const srvRes = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: regName.trim(),
          email: finalEmail,
          phone: regPhone.trim(),
          password: regPassword.trim(),
          studentCode: finalCode,
          parentPhone: regParentPhone.trim(),
          grade: regGrade,
          governorate: regGov.trim(),
          role: 'student',
        }),
      });

      const srvData = await srvRes.json();

      if (!srvRes.ok && !srvData.success) {
        setStatusMessage({
          text: srvData.error || 'هذا الحساب أو الهاتف مسجل بالفعل. يرجى تسجيل الدخول مباشرة.',
          isError: true,
        });
        setIsLoading(false);
        return;
      }

      // 2. Local context state sync
      registerStrict({
        name: regName.trim(),
        email: finalEmail,
        phone: regPhone.trim(),
        password: regPassword.trim(),
        studentCode: finalCode,
        parentPhone: regParentPhone.trim(),
        grade: regGrade,
        governorate: regGov.trim(),
        subscriptionType: 'course',
      });

      // 3. Auto-login immediately
      login(finalEmail, regName.trim(), regPhone.trim(), regGrade, finalCode);

      setIsLoading(false);
      setIsLoginModalOpen(false);
      resetFields();
    } catch {
      // Fallback local registration
      registerStrict({
        name: regName.trim(),
        email: finalEmail,
        phone: regPhone.trim(),
        password: regPassword.trim(),
        studentCode: finalCode,
        parentPhone: regParentPhone.trim(),
        grade: regGrade,
        governorate: regGov.trim(),
      });
      login(finalEmail, regName.trim(), regPhone.trim(), regGrade, finalCode);
      setIsLoading(false);
      setIsLoginModalOpen(false);
      resetFields();
    }
  };

  const resetFields = () => {
    setLoginIdentifier('');
    setLoginPassword('');
    setLoginCode('');
    setRegName('');
    setRegEmail('');
    setRegPhone('');
    setRegPassword('');
    setRegParentPhone('');
    setStatusMessage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="bg-[#0b1429] border border-cyan-800/40 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col text-slate-100 max-h-[90vh]">
        
        {/* Top Header */}
        <div className="p-4 bg-gradient-to-r from-[#0d1a3a] to-[#0b1429] border-b border-cyan-900/40 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden border border-cyan-400/80 shadow-[0_0_10px_rgba(6,182,212,0.3)] shrink-0">
              <img
                src="/assets/aistudio/image_5a8c23d0_ad0df768.jpg"
                alt="مستر عمرو السيد"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>الكيمياء مع مستر عمرو السيد</span>
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              </h2>
              <p className="text-[11px] text-cyan-400">
                {authMode === 'login' ? 'تسجيل الدخول إلى حسابك' : 'إنشاء حساب طالب جديد على المنصة'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              setIsLoginModalOpen(false);
              setStatusMessage(null);
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Mode Tabs */}
        <div className="flex border-b border-cyan-950/60 bg-[#070e20] text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setAuthMode('login');
              setStatusMessage(null);
            }}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              authMode === 'login'
                ? 'text-cyan-400 border-b-2 border-cyan-400 bg-cyan-950/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            تسجيل الدخول
          </button>
          <button
            type="button"
            onClick={() => {
              setAuthMode('register');
              setStatusMessage(null);
            }}
            className={`flex-1 py-3 text-center transition-colors cursor-pointer ${
              authMode === 'register'
                ? 'text-cyan-400 border-b-2 border-cyan-400 bg-cyan-950/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            إنشاء حساب جديد
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {/* Status Message */}
          {statusMessage && (
            <div
              className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                statusMessage.isError
                  ? 'bg-red-500/15 border border-red-500/30 text-red-200'
                  : 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-200'
              }`}
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {authMode === 'login' ? (
            <div className="space-y-4">
              {/* Method Switch: Quick Gmail vs Password Login */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-[#060a14] rounded-xl border border-cyan-950">
                <button
                  type="button"
                  onClick={() => setLoginMethod('quick_gmail')}
                  className={`py-2 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    loginMethod === 'quick_gmail'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
                  <span>دخول سريع بالجيميل</span>
                </button>
                <button
                  type="button"
                  onClick={() => setLoginMethod('password')}
                  className={`py-2 px-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    loginMethod === 'password'
                      ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5 text-cyan-300" />
                  <span>كلمة المرور / الكود</span>
                </button>
              </div>

              {loginMethod === 'quick_gmail' ? (
                /* QUICK GMAIL LOGIN FORM (NO PASSWORD REQUIRED) */
                <form onSubmit={handleQuickGmailLogin} className="space-y-3.5">
                  <div className="p-3 bg-gradient-to-br from-cyan-950/60 to-blue-950/30 border border-cyan-700/50 rounded-2xl space-y-1">
                    <div className="flex items-center gap-2 text-cyan-300 text-xs font-extrabold">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span>نظام الدخول المباشر بالجيميل (بدون كلمة سر)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      اكتب بريدك الإلكتروني (Gmail) فقط للدخول فوراً دون الحاجة لكتابة كلمة سر، ويتم حفظ بياناتك في Supabase للأبد.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      عنوان البريد الإلكتروني (Gmail)
                    </label>
                    <div className="relative">
                      <input
                        type="email"
                        required
                        value={quickGmail}
                        onChange={(e) => setQuickGmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full bg-[#060a14] border border-cyan-800/80 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 pl-9 font-mono text-left"
                        dir="ltr"
                      />
                      <Mail className="w-4 h-4 text-cyan-400 absolute left-3 top-3 pointer-events-none" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      اسم الطالب (اختياري - لتوليد كود الحماية المائية)
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={quickName}
                        onChange={(e) => setQuickName(e.target.value)}
                        placeholder="مثال: أحمد محمد (أو اتركه فارغاً)"
                        className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 pl-9"
                      />
                      <User className="w-4 h-4 text-cyan-400 absolute left-3 top-3 pointer-events-none" />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-cyan-600/30 cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>{isLoading ? 'جارٍ الربط السحابي...' : 'دخول فوري بالجيميل ⚡ (بدون كلمة سر)'}</span>
                  </button>
                </form>
              ) : (
                /* PASSWORD / CODE LOGIN FORM */
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      البريد الإلكتروني أو رقم الهاتف أو كود الطالب
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        required
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        placeholder="example@gmail.com أو 010XXXXXXXX أو AMR-101"
                        className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 pl-9 font-mono text-left"
                        dir="ltr"
                      />
                      <Mail className="w-4 h-4 text-cyan-400 absolute left-3 top-3 pointer-events-none" />
                    </div>
                  </div>

                  {loginIdentifier.trim().toLowerCase() !== 'amr12345@gmail.com' &&
                    loginIdentifier.trim() !== '01069780486' && (
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          كلمة المرور
                        </label>
                        <div className="relative">
                          <input
                            type="password"
                            required
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 pl-9 font-mono text-left"
                            dir="ltr"
                          />
                          <Lock className="w-4 h-4 text-cyan-400 absolute left-3 top-3 pointer-events-none" />
                        </div>
                      </div>
                    )}

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-3 bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-cyan-600/25 cursor-pointer mt-2 disabled:opacity-50"
                  >
                    {isLoading ? 'جارٍ التحقق...' : 'تسجيل الدخول بكلمة المرور 🚀'}
                  </button>
                </form>
              )}

              {/* Quick Teacher & Secretary 1-Click Passwordless Access */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    const res = loginStrict('amr12345@gmail.com', '', '');
                    if (res.success) {
                      setIsLoginModalOpen(false);
                      resetFields();
                    }
                  }}
                  className="w-full py-2.5 px-3 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-amber-500/10"
                >
                  <span>⚡</span>
                  <span>دخول مستر عمرو السيد (amr12345@gmail.com) بنقرة واحدة</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const res = loginStrict('secretary@amr-chem.com', '', '');
                    if (res.success) {
                      setIsLoginModalOpen(false);
                      resetFields();
                    }
                  }}
                  className="w-full py-2 px-3 bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 border border-blue-500/40 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <span>👥</span>
                  <span>دخول سكرتارية المنصة (بدون كلمة سر)</span>
                </button>
              </div>

              <div className="pt-1 text-center">
                <button
                  type="button"
                  onClick={() => setAuthMode('register')}
                  className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  ليس لديك حساب بعد؟ اضغط هنا لإنشاء حساب جديد
                </button>
              </div>
            </div>
          ) : (
            /* REGISTER FORM */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-300 mb-1">اسم الطالب كاملاً</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="مثال: أحمد محمود إبراهيم"
                    className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 pl-8"
                  />
                  <User className="w-4 h-4 text-cyan-400 absolute left-2.5 top-2.5 pointer-events-none" />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">رقم هاتف الطالب</label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="010XXXXXXXX"
                      className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 text-left font-mono pl-8"
                      dir="ltr"
                    />
                    <Phone className="w-3.5 h-3.5 text-cyan-400 absolute left-2.5 top-2.5 pointer-events-none" />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-emerald-400 mb-1 flex items-center justify-between">
                    <span>رقم ولي الأمر</span>
                    <span className="text-[10px] text-emerald-500">*مطلوب</span>
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      required
                      value={regParentPhone}
                      onChange={(e) => setRegParentPhone(e.target.value)}
                      placeholder="011XXXXXXXX"
                      className="w-full bg-[#060a14] border border-emerald-800/60 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 text-left font-mono pl-8"
                      dir="ltr"
                    />
                    <Phone className="w-3.5 h-3.5 text-emerald-400 absolute left-2.5 top-2.5 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">كلمة المرور</label>
                  <div className="relative">
                    <input
                      type="password"
                      required
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="كلمة مرور تحفظها"
                      className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 text-left font-mono pl-8"
                      dir="ltr"
                    />
                    <Lock className="w-3.5 h-3.5 text-cyan-400 absolute left-2.5 top-2.5 pointer-events-none" />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">البريد الإلكتروني (اختياري)</label>
                  <input
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="student@gmail.com"
                    className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 text-left font-mono"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">الصف الدراسي</label>
                  <select
                    value={regGrade}
                    onChange={(e) => setRegGrade(e.target.value as GradeLevel)}
                    className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="sec3">الصف الثالث الثانوي (2026)</option>
                    <option value="sec2">الصف الثاني الثانوي</option>
                    <option value="sec1">الصف الأول الثانوي</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">المحافظة</label>
                  <input
                    type="text"
                    value={regGov}
                    onChange={(e) => setRegGov(e.target.value)}
                    placeholder="مثال: القاهرة / الدقهلية"
                    className="w-full bg-[#060a14] border border-cyan-900/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-emerald-600/25 cursor-pointer mt-2 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isLoading ? 'جارٍ التسجيل...' : 'إنشاء الحساب والدخول فوراً'}</span>
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
